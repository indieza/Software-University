namespace Telecom.Tests
{
    using NUnit.Framework;

    public class Tests
    {
    }
}