namespace ParkingSystem.Tests
{
    using NUnit.Framework;

    public class SoftParkTest
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void Test1()
        {
            
        }
    }
}