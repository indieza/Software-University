﻿namespace SoftUniRestaurant.Models.Drinks.Contracts
{
    public interface IDrink
    {
    }
}
