﻿namespace SoftUniRestaurant.Models.Foods.Contracts
{
    public interface IFood
    {
    }
}
