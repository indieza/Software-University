﻿namespace SoftUniRestaurant.Models.Tables.Contracts
{
    public interface ITable
    {
    }
}
