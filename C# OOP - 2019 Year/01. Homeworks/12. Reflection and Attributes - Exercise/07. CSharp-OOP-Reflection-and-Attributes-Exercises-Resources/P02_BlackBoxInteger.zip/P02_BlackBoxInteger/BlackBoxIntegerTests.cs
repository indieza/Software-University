﻿namespace P02_BlackBoxInteger
{
    using System;

    public class BlackBoxIntegerTests
    {
        public static void Main()
        {
            //TODO put your reflection code here
        }
    }
}
