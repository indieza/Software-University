namespace AnimalCentre.IO
{
    public interface IReader
    {
        string readData();
    }
}