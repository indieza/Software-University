function acceptance() {
	console.log('TODO...')
}