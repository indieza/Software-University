let SkiResort = require('./solution');

describe('SkiResort', function () {
    //TODO... =)
});
