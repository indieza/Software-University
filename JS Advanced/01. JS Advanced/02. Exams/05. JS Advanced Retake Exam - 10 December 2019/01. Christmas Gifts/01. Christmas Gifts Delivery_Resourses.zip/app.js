function solution() {
    //TO DO
}