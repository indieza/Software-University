﻿namespace SIS.MvcFramework
{
    public class ErrorViewModel
    {
        public string Error { get; set; }
    }
}
