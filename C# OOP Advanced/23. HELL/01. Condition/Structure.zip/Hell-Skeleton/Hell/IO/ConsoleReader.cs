﻿using System;

public class ConsoleReader
{
    public string ReadLine()
    {
        return Console.ReadLine();
    }
}