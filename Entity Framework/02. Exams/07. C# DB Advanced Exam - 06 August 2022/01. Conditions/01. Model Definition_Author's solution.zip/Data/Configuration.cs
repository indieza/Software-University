﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(local);Database=FootballersExam;Trusted_Connection=True";
    }
}
