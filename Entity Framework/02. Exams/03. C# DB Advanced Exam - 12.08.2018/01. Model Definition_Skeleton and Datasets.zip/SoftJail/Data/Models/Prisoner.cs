﻿namespace SoftJail.Data.Models
{
    public class Prisoner
    {

    }
}