﻿namespace Cinema.Data.Models
{
    public class Movie
    {
        
    }
}
