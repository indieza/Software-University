﻿namespace FastFood.DataProcessor.Dto.Import
{
	public class OrderItemDto
	{
		public string Name { get; set; }

		public int Quantity { get; set; }
	}	
}