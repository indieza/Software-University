﻿namespace VaporStore.Data.Models
{
	public class Game
    {
	}
}
