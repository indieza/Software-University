﻿namespace MiniORM
{
	// TODO: Create your DbContext class here.
}